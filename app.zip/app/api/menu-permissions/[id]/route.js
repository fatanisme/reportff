export { GET, PUT, DELETE } from "../../page-permissions/[id]/route";
