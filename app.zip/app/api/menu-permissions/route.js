export { GET, POST } from "../page-permissions/route";
